eduonix-solr
============

eduonix-solr is a tutorial  project for [EDUONIX](http://www.eduonix.com/) Projects for Hadoop.
