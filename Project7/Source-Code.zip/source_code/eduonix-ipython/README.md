# eduonix-ipython

- Sci_Java code is for eclipse on the Cloudera vm with the build path pointing to all the hadoop- and supporting jars in the user/...  
- Java code is there to show that for simple mr jobs at least pydoop is quicker and provides cleaner code.
